import sys
import config
import random
import datetime
import subprocess
import pyttsx3
import speech_recognition as sr
from fuzzywuzzy import fuzz

def currentTime():
    return datetime.datetime.now().strftime("%H:%M")

def openBrowser():
    subprocess.run(["open", "-a", "Google Chrome", "https://www.google.com"])
    return 'відкрила браузер'

def openYoutube():
    subprocess.run(["open", "-a", "Google Chrome", "https://www.youtube.com/"])
    return 'відкрила ютуб'

def joke():
    jokes = ['Как смеются программисты? ... ехе ехе ехе','ЭсКьюЭль запит заходить в бар, підходить до двох столів і запитує .. «м+ожно приєднатися?»','Программіст це машина для перетворення кофе в код']
    return random.choice(jokes)
def exit():
    engine = pyttsx3.init()
    engine.say("Бувай.")
    engine.runAndWait()
    sys.exit()

def mainSearcher(language):
    engine = pyttsx3.init()
    print(f"{config.VA_NAME} (v{config.VA_VER}) почала роботу...")
    engine.say("Я почала роботу...")
    engine.runAndWait()
    r = sr.Recognizer()
    while True:
        with sr.Microphone() as source:
            print("Скажіть щось...")
            audio = r.listen(source)
        try:
            text = r.recognize_google(audio, language = 'uk-UA')
            print("Ви сказали:", text)
            if any(fuzz.ratio(text.lower(), alias.lower()) > 60 for alias in config.VA_ALIAS_UKR):
                engine.say("Що ви хотіли?")
                engine.runAndWait()
                continue
            for keyword, command in zip(
                [config.VA_CMD_STOP, config.VA_CMD_JOKEN,
                config.VA_CMD_YOTUBE,
                config.VA_CMD_BROWSER,
                config.VA_CMD_TIME],
                [exit, joke, openYoutube,openBrowser, currentTime]):
                if any(fuzz.ratio(text.lower(), kwd.lower()) > 60 for kwd in keyword):
                    engine.say(command())
                    engine.runAndWait()
                    continue
        except sr.UnknownValueError:
            print("Не можу розпізнати голос")
        except sr.RequestError as e:
            print("Помилка сервісу Google Speech Recognition; {0}".format(e)) 
