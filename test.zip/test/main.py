import command
import eel
import sys

@eel.expose
def checkboxChanged(isChecked):
    if isChecked:
        command.mainSearcher('uk-UA')

eel.init('web')
eel.start('index.html', size=(600, 725))
